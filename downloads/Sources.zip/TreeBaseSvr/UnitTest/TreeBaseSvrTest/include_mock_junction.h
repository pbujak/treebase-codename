#if !defined(__INCLUDE_MOCK_JUNCTION__)
#define __INCLUDE_MOCK_JUNCTION__

#define JUNCTION_H
#define STORAGE_H

#include "MockStorage.h"

namespace Junction
{
    inline void removeJunctionTarget(SEGID_F& a_segID) {};
};


#endif // __INCLUDE_MOCK_JUNCTION__
