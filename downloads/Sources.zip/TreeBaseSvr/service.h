#ifndef _SERVICE_H_
#define _SERVICE_H_

namespace Service
{
	bool Install();
	bool UnInstall();
	bool Run();
	bool Stop();
}

#endif // _SERVICE_H_