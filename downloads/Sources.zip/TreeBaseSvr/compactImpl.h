#ifndef _COMPACT_IMPL_H_
#define _COMPACT_IMPL_H_




#endif // _COMPACT_IMPL_H_