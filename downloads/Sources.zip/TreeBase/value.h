// value.h
#if !defined(_VALUE_H_)
#define _VALUE_H_

#include "Treebase.h"
#include "TreeBaseInt.h"

TBASE_VALUE* VALUE_ItemEntry2Value(TBITEM_ENTRY *a_pEntry);


#endif //_VALUE_H_
