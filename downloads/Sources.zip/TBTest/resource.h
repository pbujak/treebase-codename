//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TBTest.rc
//
#define IDD_TBTEST_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDD_EDITSEC                     129
#define IDD_EXPLORER                    130
#define IDI_FOLDER                      131
#define IDR_LISTMENU                    132
#define IDD_VALEDIT                     133
#define IDC_LIST1                       1000
#define IDC_NEW                         1001
#define IDC_NAME                        1002
#define IDC_DELETE                      1002
#define IDC_ADDRESS                     1003
#define IDC_UPDATE                      1003
#define IDC_ROLLBACK                    1004
#define IDC_AGE                         1005
#define IDC_LIST                        1005
#define IDC_EDIT                        1006
#define IDC_BACK                        1007
#define IDC_NEW_SECTION                 1008
#define IDC_LABEL                       1010
#define IDC_DELETE_LABEL                1011
#define IDC_TEXT                        1013
#define IDC_INTEGER                     1014
#define IDC_FLOAT                       1015
#define IDC_POINT_X                     1016
#define IDC_POINT_Y                     1017
#define IDC_RECT_TOP                    1018
#define IDC_RECT_BOTTOM                 1019
#define IDC_RECT_RIGHT                  1020
#define IDC_RECT_LEFT                   1021
#define IDC_FPOINT_X                    1022
#define IDC_FPOINT_Y                    1023
#define IDC_FRECT_TOP                   1024
#define IDC_FRECT_BOTTOM                1025
#define IDC_FRECT_RIGHT                 1026
#define IDC_FRECT_LEFT                  1027
#define IDC_VALTYPE                     1029
#define IDC_VALNAME                     1030
#define IDC_TESTCASES                   1031
#define IDC_RUNTEST                     1032
#define IDC_BUTTON2                     1033
#define IDC_RUNALLTESTS                 1033
#define ID_DELETE                       32771
#define ID_NEWSECTION                   32772
#define ID_EDIT_VALUE                   32773
#define ID_ADD_VALUE                    32774
#define ID_ADD_IMAGE                    32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1034
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
