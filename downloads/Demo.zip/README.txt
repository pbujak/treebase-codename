1) TreeBaseEngine.exe should be first installed (create windows service)
      
      TreeBaseEngine /install

   It requires administrative privileges.

2) TBTest.exe could be run only after instalation of TreeBaseEngine.exe. It contains a simple browser and system tests.

3) Before deletion TreeBaseEngine.exe should be uninstalled

      TreeBaseEngine /uninstall
